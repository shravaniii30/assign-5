void main() {
  int i = 10;
  int num = 5;
  while (i > 0) {
    print(i * num);
    i--;
  }
}
